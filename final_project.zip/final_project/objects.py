from ball import *
from paddle import *
from canvas import *
from score import *

score = Score(canvas, 'green')
paddle = Paddle(canvas, 'blue')
ball = Ball(canvas, paddle, 'red', score)
game_over_text = canvas.create_text(250, 200, text='Game over', state='hidden')