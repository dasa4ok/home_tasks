from tkinter import *
import random
import time
from ball import *
from paddle import *
from canvas import *
from objects import *
from score import *

while 1:
    if ball.hit_bottom == False and paddle.started == True:
        ball.draw()
        paddle.draw()
    if ball.hit_bottom == True:
        time.sleep(1)
        canvas.itemconfig(game_over_text, state='normal')
    tk.update_idletasks()
    tk.update()
    time.sleep(0.01)

tk.mainloop()
