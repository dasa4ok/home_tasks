a = ['fur', 'skin', 'coat', 'pelage', 'jack']
for i in range(len(a)):
    if 'a' in a[i]:
        print(len(a[i]))
        break
