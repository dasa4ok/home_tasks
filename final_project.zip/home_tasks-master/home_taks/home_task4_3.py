a = [1, 2, 3, 4]
a = a[::-1]
print(a)