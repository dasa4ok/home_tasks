list_for_chenging  = [1, 2, 3, 4, 5, 6, 7, 8]
new_list = [i ** i for i in list_for_chenging]
print(new_list)